package com.example.question.model;

public enum UserType {
    designer, player
}