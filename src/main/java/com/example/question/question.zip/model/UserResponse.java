package com.example.question.model;

public class UserResponse {
   public static String UNAUTHORIZED = "لطفا وارد حساب کاربری خود شوید";
}
